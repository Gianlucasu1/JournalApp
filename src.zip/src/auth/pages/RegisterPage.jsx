import React from 'react'

export const RegisterPage = () => {
  return (
    <div>RegisterPage</div>
  )
}
