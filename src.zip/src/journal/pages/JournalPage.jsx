
import { Typography } from '@mui/material'
import React from 'react'

export const JournalPage = () => {
  return (
    <>
    <Typography variant='h1'>Journal Page</Typography>
    
    </>
  )
}
